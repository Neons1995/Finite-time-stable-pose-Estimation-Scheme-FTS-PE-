function MyPlot_FTS_PE_N(t,g,h)

figure(2);
hP=zeros(3,3,size(g,3));
Phi=zeros(1,size(g,3));
size(g,3)

sum_att_fts = 0;
sum_att_dq = 0;
s_att_fts = 0;
s_att_dq = 0;
for k=1:size(g,3)
%     hP(:,:,k)=ProjSO3(h(1:3,1:3,k));
    Phi(1,k)=acos(0.5*(trace(h(1:3,1:3,k))-1));
    
    sum_att_fts = sum_att_fts + (Phi(1,k)'*Phi(1,k));
    
    s_att_fts = s_att_fts + (Phi(1,k));
end
RMS_fts_att = sqrt(sum_att_fts/size(g,3));

avg_fts_att = s_att_fts/size(g,3);

sum_att_vpe = 0;
s_att_vpe = 0;

subplot(2,1,1);
grid on
hold on
plot(t(1:end),Phi,'LineWidth',2 )
hold on
xlabel('$t\ \mathrm{(s)}$','interpreter', 'latex','Fontsize',18)
ylabel('$\phi\ (\mathrm{rad})$','interpreter','latex','Fontsize',18)
hd1=legend('FTS-PE');
set(hd1,'interpreter','latex','Fontsize',16)
set(hd1,'box','off')
set(hd1,'Orientation','horizontal','Location','northeast')

subplot(2,1,2);
grid on
hold on
len_h = length(h(1:3,4,:));

sum_fts = 0;
sum_dq = 0;
for i=1:len_h
   pp(:,i) = h(1:3,4,i);
   
   sum_fts = sum_fts + (pp(:,i)'*pp(:,i));
end
RMS_fts_pos = sqrt(sum_fts/len_h);
RMS_dq_pos = sqrt(sum_dq/len_h);

avg_fts_pos = (sum_fts/len_h);
avg_dq_pos = (sum_dq/len_h);

sum_vpe = 0;


for i=1:length(t)
    norm_fts(1,i) = norm(pp(:,i));
end
plot(t, norm_fts(1,:),'LineWidth',2);
hd2=legend('FTS-PE');
set(hd2,'interpreter','latex','Fontsize',16)
set(hd2,'box','off')
set(hd2,'Orientation','horizontal','Location','northeast')

xlabel('$t\ \mathrm{(s)}$','interpreter', 'latex','Fontsize',18)
ylabel('$\|\chi\| (\mathrm{m})$','interpreter','latex','Fontsize',18)


figure(14)
plot(t, pp(1,:),'LineWidth',2);
hold on
plot(t, pp(2,:),'LineWidth',2);
hold on
plot(t, pp(3,:),'LineWidth',2);
hd2=legend('FTS-PE');
set(hd2,'interpreter','latex','Fontsize',16)
set(hd2,'box','off')
set(hd2,'Orientation','horizontal','Location','northeast')

xlabel('$t\ \mathrm{(s)}$','interpreter', 'latex','Fontsize',18)
ylabel('$\|\chi\| (\mathrm{m})$','interpreter','latex','Fontsize',18)
