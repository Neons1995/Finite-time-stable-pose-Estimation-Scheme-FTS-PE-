function Adg = AdSE3(g)
% AdSE3: Computes the matrix representation of Ad_g for g in SE(3)
% Created: June 23, 2012, AKS

R=g(1:3,1:3);
b=g(1:3,4);
bcross=skew(b);
Adg=[R zeros(3,3); bcross*R R];

end

