% Main code for FTS-PE Paper 
% 5/25/2025, N. S
% Syracuse University

clc;
close all;
clear;

global h K kp kv kw kappa e1 e2 e3 p mu beta alpha_1 alpha_2
%%%%%%% constants %%%%%%%%%%%%%%%%%%%
K =  0.0051005*diag([ 1.3; 1.2; 1.1]);
kp = 10.1;   
kv = 010.02;
kw = 011.01;
kappa = 1.1;
p = 13/11;
mu  = 1;
alpha_1 = 090*0.985001;
alpha_2 = 010.02*0.0959;
e1 = [1  0  0]';
e2 = [0  1  0]';
e3 = [0  0  1]';
beta = [-0.01 -0.005 0.02]';
%%%%%%%%%%%%%% SVD method to obtain R and b %%%%%%%%%%%%%%%%%
bagfile = '..........\vrot.bag'; 

bag = rosbag(bagfile);
rostopics = bag.AvailableTopics
M = bag.MessageList

op1= select(bag, 'Topic', '/zed2i/zed_node/imu/data'); 
op2 = select(bag, 'Topic', '/zed2i/zed_node/odom');
op3= select(bag, 'Topic', '/zed2i/zed_node/pose'); 
%%%
start = bag.StartTime;
ts = timeseries(op2);
ts3 = timeseries(op3);

op_1= readMessages(op1);
op_2 = readMessages(op2);
op_3= readMessages(op3);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=1:length(op_3)

   Position_camera(:,i) = [op_3{i,1}.Pose.Position.X; op_3{i,1}.Pose.Position.Y; op_3{i,1}.Pose.Position.Z];
  
   Atitude_camera(:,i) = [op_3{i,1}.Pose.Orientation.X; op_3{i,1}.Pose.Orientation.Y; op_3{i,1}.Pose.Orientation.Z; op_3{i,1}.Pose.Orientation.W];
   Linear_twist_camera(:,i) = [op_2{i,1}.Twist.Twist.Linear.X; op_2{i,1}.Twist.Twist.Linear.Y ;op_2{i,1}.Twist.Twist.Linear.Z];
end


csvwrite('Pos_camera.txt',Position_camera)
csvwrite('ori_camera.txt',Atitude_camera)
csvwrite('twist_camera.txt',Linear_twist_camera)


Position_cam_o = csvread('Pos_camera.txt');
Atitude_cam = csvread('ori_camera.txt');
linear_twist_cam = csvread('twist_camera.txt');



sim_time =30.8178; 

length_cam = length(Position_cam_o)-1;
t1_ = 0:vpa(sim_time/length_cam):sim_time;
var1 = double(double(t1_));

Position_cam = [Position_cam_o(1,:); Position_cam_o(2,:); Position_cam_o(3,:)]; 
cam_position = [Position_cam(1,:); Position_cam(2,:); Position_cam(3,:)];


cam_attitude_q = [Atitude_cam(1,:); Atitude_cam(2,:); Atitude_cam(3,:); Atitude_cam(4,:)];

for i=1:length(cam_attitude_q)
    cam_attitude_R(:,:,i) = quat2rotm([cam_attitude_q(4,i) cam_attitude_q(1,i) cam_attitude_q(2,i) cam_attitude_q(3,i)]);

    g_SDK(:,:,i) = [cam_attitude_R(:,:,i) cam_position(:,i); 0 0 0 1];
end



for i=1:(length(cam_attitude_q)-2)
  
    g_SDK_new(:,:,i) = g_SDK(:,:,i);
end


cam_q = [Atitude_cam(4,:); Atitude_cam(1,:); Atitude_cam(2,:); Atitude_cam(3,:)]';
var1 = double(double(t1_));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

imu_messages=readMessages(op1, 'DataFormat', 'struct');
IMU_timestamps=op1.MessageList.Time; 
IMU_timestamps_Sec=seconds(IMU_timestamps - IMU_timestamps(1));
ts1=timeseries(op1);

%%
AngularVelocity_S=zeros(3,length(op_1));

for i=1:length(op_1)
AngularVelocity_S(:,i) = [op_1{i,1}.AngularVelocity.X; op_1{i,1}.AngularVelocity.Y ;op_1{i,1}.AngularVelocity.Z];
end
%%%%% SVD %%%%%%%
tpic = '/zed2i/zed_node/point_cloud/cloud_registered';
pcSel = select(bag, 'Topic', tpic)
pcMsgs = readMessages(pcSel, 'DataFormat','struct')
pcMsgs{1}.Header.FrameId
frame_timestamps= pcSel.MessageList.Time;
frame_timestamps_sec=seconds(frame_timestamps - frame_timestamps(1));
number_frames=length(frame_timestamps_sec);
Omega_eachframe1=zeros(number_frames,3);

AngularVelocity1=AngularVelocity_S';

offset_time=seconds(IMU_timestamps(1)- frame_timestamps(1));
Offset=ones(10807,1)*offset_time;

for i=1:number_frames -1
    t_start=frame_timestamps_sec(i);
    t_final=frame_timestamps_sec(i+1);

    index= find(IMU_timestamps_Sec >= t_start & IMU_timestamps_Sec < t_final);

   if ~isempty(index)
        Y=mean(AngularVelocity1(index,:),1);
         Omega_eachframe1(i,1)=Y(1,1);
         Omega_eachframe1(i,2)=Y(1,2);
         Omega_eachframe1(i,3)=Y(1,3);
   else
     Omega_eachframe1=zeros(3,1);
    end

end

last_frame_index=find(IMU_timestamps_Sec >= frame_timestamps_sec(end));

if ~isempty(last_frame_index)
 L =mean(AngularVelocity1(index,:),1);
    Omega_eachframe1(end,1)=L(1,1);
    Omega_eachframe1(end,1)=L(1,2);
    Omega_eachframe1(end,1)=L(1,3);
else
    Omega_eachframe1(end,:) = zeros(3,1);
end
%%%%%%%%%%%%%%%%%%%%%%%%%
N = numel(pcMsgs)
n = N-1;
Frames = (1:n)';
%%%%%%%%%%%%%%%%%%%%%%%%%%

numofframes=n;

numIMUsamples=length(op_1);

AngularVelocity1=AngularVelocity_S';
length(op_1)
Samples=floor(length(op_1)/n);
Omega_eachframe=zeros(n,3);
Z_f1 = zeros(3,n);
Z_m1= zeros(3,n);
c = zeros(3,n);

for i =1:n

    S_index=(i-1)*Samples+1;
    F_index=i*Samples;

    if i==n
        F_index=length(op_1);
    end

   Omega_eachframe(i,:)=mean(AngularVelocity1(S_index:F_index,:),1);
end




for f=2:(n-1)


Z_f1(:,1)=[0;0;0]; 

Z_f1(:,2)=[0;0;0];

Z_m1(:,f) =  Omega_eachframe(f,:)'; 
c(:,f) = Z_f1(:,f) - Z_m1(:,f); 
lambda_c =1;
zi = Z_f1(:,f) - Z_f1(:,f-1);
r=p;
D_zi = (  ((zi' * zi)^(1-(1/r))) - lambda_c)/( ((zi' * zi)^(1-(1/r))) + lambda_c); 
D_ci = (  ((c(:,f)' * c(:,f))^(1-(1/r))) - lambda_c)/( ((c(:,f)' * c(:,f))^(1-(1/r))) + lambda_c); 
Z_f1(:,f+1)=Z_m1(:,f) + D_ci * c(:,f) + D_zi * (Z_f1(:,f) - Z_f1(:,f-1)); 
end

phi1 = zeros(n,1);
phi1_f = zeros(n,1);
phi_t = zeros(n,1);
phi_t_f = zeros(n,1);
p_bar_t1_norm=zeros(n,1);
p_bar_s1_norm=zeros(n,1);
R_=zeros(3,3,n);
Det=zeros(n,1);
M=zeros(3,3,n);
Us=zeros(3,3,n);
Vs=zeros(3,3,n);

R_f=zeros(3,3,n);
Det_f=zeros(n,1);
M_f=zeros(3,3,n);
Us_f=zeros(3,3,n);
Vs_f=zeros(3,3,n);

qs1=zeros(n,3);
qt1=zeros(n,3);
R=zeros(3,3,n);
R_t=zeros(3,3,n+1);
r=zeros(n,1);
b=zeros(3,n);

qs1_f=zeros(n,3);
qt1_f=zeros(n,3);
R_f=zeros(3,3,n);
R_t_f=zeros(3,3,n+1);
r_f=zeros(n,1);
b_f=zeros(3,n);

p_bar_s1=zeros(n,3);
TranslationalV=zeros(n,3);
p_bar_t1=zeros(n,3);
p_bar_s1_f=zeros(n,3);
p_bar_t1_f=zeros(n,3);

for i = 1:(N-1)

 num_Msgs = length(pcMsgs);
timestamps = zeros(num_Msgs,1);

for j = 1:num_Msgs
    sec = pcMsgs{j}.Header.Stamp.Sec;
    nsec = pcMsgs{j}.Header.Stamp.Nsec;
    timestamps(j) = double(sec) + double(nsec) * 1e-9;
end
dt3 = diff(timestamps);              
avg_dt = mean(dt3);  
h=avg_dt
pointcloud_Frequency = 1/avg_dt; 

p_s= msg2xyz(pcMsgs{i}); 
p_t = msg2xyz(pcMsgs{i+1});


    noNaN = all(~isnan(p_s), 2) & all(~isnan(p_t), 2);
p_s = p_s(noNaN, :);
p_t = p_t(noNaN, :);

noInf = all(~isinf(p_s), 2) & all(~isinf(p_t), 2);
p_s = p_s(noInf, :);
p_t = p_t(noInf, :);

    Z_f2 = zeros(3,length(p_s));
    Z_m2= zeros(3,length(p_s));
    c2 = zeros(3,length(p_s));


for f=2:(length(p_s)-1)

Z_f2(:,1)=[0;0;0]'; 

Z_f2(:,2)= [0;0;0]';

Z_m2(:,f) =  p_s(f,:)'; 
c2(:,f) = Z_f2(:,f) - Z_m2(:,f); 

z2i = Z_f2(:,f) - Z_f2(:,f-1);
r=p;
D_z2i = (  ((z2i' * z2i)^(1-(1/r))) - lambda_c)/( ((z2i' * z2i)^(1-(1/r))) + lambda_c); 
D_c2i = (  ((c2(:,f)' * c2(:,f))^(1-(1/r))) - lambda_c)/( ((c2(:,f)' * c2(:,f))^(1-(1/r))) + lambda_c); 
Z_f2(:,f+1)=Z_m2(:,f) + D_c2i * c2(:,f) + D_z2i * (Z_f2(:,f) - Z_f2(:,f-1)); 
end
Z_f2_dot=zeros(3,length(p_s));
for e=1:length(p_s)
    dt = h;
    if e == length(p_s)
        Z_f2_dot(:,e)=Z_f2_dot(:,e-1);
    else
    Z_f2_dot(:,e)= (Z_f2(:,e+1) - Z_f2(:,e)) / dt; 
    end
end


 Z_f3 = zeros(3,length(p_t));
 Z_m3= zeros(3,length(p_t));
 c3 = zeros(3,length(p_t));


for f=2:(length(p_t)-1)

Z_f3(:,1)=[0;0;0]';

Z_f3(:,2)=[0;0;0]';

Z_m3(:,f) =  p_t(f,:)';
c3(:,f) = Z_f3(:,f) - Z_m3(:,f); 


z3i = Z_f3(:,f) - Z_f3(:,f-1);
r=p;
D_z3i = (  ((z3i' * z3i)^(1-(1/r))) - lambda_c)/( ((z3i' * z3i)^(1-(1/r))) + lambda_c); 
D_c3i = (  ((c3(:,f)' * c3(:,f))^(1-(1/r))) - lambda_c)/( ((c3(:,f)' * c3(:,f))^(1-(1/r))) + lambda_c); 
Z_f3(:,f+1)=Z_m3(:,f) + D_c3i * c3(:,f) + D_z3i * (Z_f3(:,f) - Z_f3(:,f-1)); 
end

    p_s_f = Z_f2';
    p_t_f = Z_f3';


    p_bar_s = mean(p_s, 1);
    p_bar_s_f= mean(p_s_f, 1);
    p_bar_s1(i,:)=p_bar_s;
    p_bar_s1_f(i,:)=p_bar_s_f;
    
    p_bar_t = mean(p_t, 1);
    p_bar_t_f= mean(p_t_f, 1);
    p_bar_t1(i,:)=p_bar_t;
    p_bar_t1_f(i,:)=p_bar_t_f;


    qs = p_s - p_bar_s;
    qt = p_t - p_bar_t;

    M(:,:,i) = qt'*qs; 

   
    qs_f = p_s_f - p_bar_s_f;
    qt_f = p_t_f - p_bar_t_f;

    M_f(:,:,i) = qt_f'*qs_f;   
    
    
 
    [U_s,S,V_s] = svd(M(:,:,i));
   
    Us(:,:,i)=U_s;
    Vs(:,:,i)=V_s;


    [U_s_f,S,V_s_f] = svd(M_f(:,:,i));
   
    Us_f(:,:,i)=U_s_f;
    Vs_f(:,:,i)=V_s_f;

    R(:,:,i)=Us(:,:,i)*Vs(:,:,i)';
    b(:,i)=p_bar_t' - R(:,:,i)*p_bar_s';
    Det(i)=det(Us(:,:,i));
   
    R_f(:,:,i)=Us_f(:,:,i)*Vs_f(:,:,i)';
    b_f(:,i)=p_bar_t_f' - R_f(:,:,i)*p_bar_s_f';

phi1(i)  = acos((trace(R(:,:,i))-1)/2);
phi1_f(i)  = acos((trace(R_f(:,:,i))-1)/2);

p_bar_t1_norm(i)=norm(p_bar_t1);
p_bar_s1_norm(i)=norm(p_bar_s1);


ones_=ones(length(p_s),3);
S1=ones_(:,1)*Z_f1(1,i);
S2=ones_(:,2)*Z_f1(2,i);
S3=ones_(:,3)*Z_f1(3,i);
Omega_=[S1 S2 S3];
nu_f = Z_f2_dot';
D1=zeros(length(p_s),3);
for k =1: length(p_s)
 D=cross(p_s_f(k,:),Omega_(k,:)); 
 D1(k,:)=D - nu_f(k,:);
 end
 V=mean(D1,1);
 TranslationalV(i,:)=V;
end


R_t(:,:,1)=eye(3);
b_tt=zeros(3,n+1);
b_t=zeros(3,n);
for k2= 1:(N-1)
        R_t(:,:,k2+1)=R(:,:,k2)*R_t(:,:,k2); 
        b_tt(:,k2+1)=b_tt(:,k2)+R_t(:,:,k2+1)'*b(:,k2); 
        k2=k2+1;
end

R_t1=zeros(3,3,n);
for f=1:N-1
    R_t1(:,:,f)=R_t(:,:,f+1);
    phi_t(f)  = acos((trace(R_t1(:,:,f))-1)/2);

    b_t(:,f)=b_tt(:,f+1);
end

R_t_T = permute(R_t,[2 1 3]);

R_t1_T = permute(R_t1,[2 1 3]);

R_t_f(:,:,1)=eye(3);
b_tt_f=zeros(3,n+1);
b_t_f=zeros(3,n);
for k2= 1:(N-1)
        R_t_f(:,:,k2+1)=R_f(:,:,k2)*R_t_f(:,:,k2);
        b_tt_f(:,k2+1)=b_tt_f(:,k2)+R_t_f(:,:,k2+1)'*b_f(:,k2); 
        k2=k2+1;
end
R_t1_f=zeros(3,3,n);
for f=1:N-1
    R_t1_f(:,:,f)=R_t_f(:,:,f+1);
    phi_t_f(f)  = acos((trace(R_t1_f(:,:,f))-1)/2);

    b_t_f(:,f)=b_tt_f(:,f+1);
end


R_t_f_T= permute(R_t_f,[2 1 3]);

R_t1_f_T= permute(R_t1_f,[2 1 3]);

bar_p=p_bar_s1_f(1,:)'; 
[bar_am, bar_p] = Measured_points_new(p_bar_s1_f(1,:),R_t1_f_T,b_t_f);


t0 = 0;

arraySize = n;           
n1 = arraySize - 1;      
t_end1 = (n1 + 1) * h - eps;  
t_end = (n - 1) * h;

t = 0:h:t_end;

Um = zeros(3,3,arraySize); 
Uhat = zeros(3,3,arraySize);
xi=[Z_f1;TranslationalV'];


g_act(:,:,1) = [R_t1_T(:,:,1) b_t(:,1); 0 0 0 1];
[E(:,:,1), W(:,:,1), Um(:,:,1)] = measureVect(R_t1_T(:,:,1));

xi_m = zeros(6,arraySize);
for k=1:n1 
xi_m(:,k) = 1*xi(:,k);
end

for k=2:n

g_act(:,:,k) = [R_t1_T(:,:,k) b_t(:,k); 0 0 0 1];
[E(:,:,k), W(:,:,k), Um(:,:,k)] = measureVect(g_act(1:3,1:3,k));
end



%% 
Um_VE = zeros(3,3,arraySize);
ghat_matrix = zeros(4,4,arraySize+1);
varphi = zeros(6,arraySize+1); 
Phi_FTS = zeros(1,arraySize) ;
xi_hat = zeros(6,arraySize);


varphi(:,1) = [0.75;-.5;0.05;1.5;0.4;1.8];



bh = [1.5; 1.0; 1];
ghat_matrix(:,:,1) = [expmso3(0.9*pi*[1; 0 ; 0]) bh; 0 0 0 1];
xi_hat(:,1) = xi_m(:,1) - AdSE3(invSE3(ghat_matrix(:,:,1)))*varphi(:,1); 
%% FTS pose estimation

tc_fts = cputime;
xi_hat_vec=zeros(6,arraySize);
for i = 1:arraySize 
    [ghat_matrix(:,:,i+1), varphi(:,i+1), W(:,:,i), Um_VE(:,:,i) ,yy, sLl, Psi_o, Phi_o,int_val] = ...
        FTS_update(xi_m(:,i),ghat_matrix(:,:,i),varphi(:,i), Um(:,:,i), bar_am(:,i), bar_p, xi_hat(:,i));
    Psi_o(:,i) = Psi_o;
    Phi_o(:,i) = Phi_o;
    xi_hat_vec(:,i) = int_val; 
end

end_time_fts = cputime-tc_fts;
disp(cputime-tc_fts)    
Q_att=zeros(3,3,arraySize);
phi=zeros(1,arraySize);
h_mat=zeros(4,4,arraySize);
h_mat_SDK=zeros(4,4,arraySize);

for k=1:arraySize   
    Q_att(:,:,k) = g_act(1:3,1:3,k)*ghat_matrix(1:3,1:3,k)^(-1);

    phi(:,k) = acos(0.5*(trace(Q_att(:,:,k))-1)); 
end

grid on

 for k=1:arraySize
     h_mat(:,:,k) = g_act(:,:,k)*ghat_matrix(:,:,k)^(-1);
     h_mat_SDK(:,:,k) = g_SDK_new(:,:,k)*ghat_matrix(:,:,k)^(-1);

 end



figure(7);
t4=1:n;
plot(t4,p_bar_t1_norm(:),'LineWidth', 1,'Color','b');
hold on
xlabel('Frame','interpreter','latex','FontSize',18);
ylabel('$norm pt$','interpreter','latex','FontSize',18);
 
figure(8);
plot(t4,p_bar_s1_norm(:),'LineWidth', 1,'Color','b');
hold on
xlabel('Frame','interpreter','latex','FontSize',18);
ylabel('$norm ps$','interpreter','latex','FontSize',18);

figure(9);
t4=1:n;
plot(t4,phi_t(:),'LineWidth', 1,'Color','b');
hold on
xlabel('Frame','interpreter','latex','FontSize',18);
ylabel('$\Phi_t$ rad','interpreter','latex','FontSize',18);

figure(12);
subplot(2,1,1);
grid on
hold on
plot(t,xi_hat_vec(1,:),'LineWidth', 2);

hold on
plot(t,xi_hat_vec(2,:));
plot(t,xi_hat_vec(3,:));
xlabel('$t\ \mathrm{(s)}$','interpreter','latex','FontSize',18);
ylabel('$\hat{\Omega}$ (rad/s)','interpreter','latex','FontSize',18);
hd1=legend('$\hat{\Omega}_x$','$\hat{\Omega}_y$','$\hat{\Omega}_z$');
set(hd1,'interpreter','latex','Fontsize',16)
set(hd1,'box','off')
set(hd1,'Orientation','horizontal','Location','northeast')

subplot(2,1,2);
grid on
hold on
plot(t,xi_hat_vec(4,:),'LineWidth', 2);
hold on
plot(t,xi_hat_vec(5,:),'LineWidth', 2);
plot(t,xi_hat_vec(6,:),'LineWidth', 2);
xlabel('$t\ \mathrm{(s)}$','interpreter','latex','FontSize',18);
ylabel('$\hat{\nu}$ (m/s)','interpreter','latex','FontSize',18);
hd1=legend('$\hat{\nu}_x$','$\hat{\nu}_y$','$\hat{\nu}_z$');
set(hd1,'interpreter','latex','Fontsize',16)
set(hd1,'box','off')
set(hd1,'Orientation','horizontal','Location','northeast')



figure(13);
subplot(2,1,1);
grid on 
hold on
plot(t,varphi(1,1:n),'LineWidth', 2);

hold on
plot(t,varphi(2,1:1:n),'LineWidth', 2);
plot(t,varphi(3,1:1:n),'LineWidth', 2); 

xlabel('$t\ \mathrm{(s)}$','interpreter','latex','FontSize',18);
ylabel('$\omega$ (rad/s)','interpreter','latex','FontSize',18);
hd1=legend('$\omega_x$','$\omega_y$','$\omega_z$');
set(hd1,'interpreter','latex','Fontsize',16)
set(hd1,'box','off')
set(hd1,'Orientation','horizontal','Location','northeast')

subplot(2,1,2);
grid on
hold on
plot(t,varphi(4,1:n),'LineWidth', 2); 
hold on
plot(t,varphi(5,1:1:n),'LineWidth', 2); 
plot(t,varphi(6,1:1:n),'LineWidth', 2); 
xlabel('$t\ \mathrm{(s)}$','interpreter','latex','FontSize',18);
ylabel('$\upsilon$ (m/s)','interpreter','latex','FontSize',18);
hd1=legend('$\upsilon_x$','$\upsilon_y$','$\upsilon_z$');
set(hd1,'interpreter','latex','Fontsize',16)
set(hd1,'box','off')
set(hd1,'Orientation','horizontal','Location','northeast')

%%%%%%%%%%%
MyPlot_FTS_PE_N(t,g_act,h_mat)


disp('xi_hat')
xi_hat(:,1) 


function P = msg2xyz(msg)
floats = msg.PointStep/4;
all = typecast(msg.Data, 'single');
pts = reshape(all,floats, []).';
P = pts(:,1:3);
end



