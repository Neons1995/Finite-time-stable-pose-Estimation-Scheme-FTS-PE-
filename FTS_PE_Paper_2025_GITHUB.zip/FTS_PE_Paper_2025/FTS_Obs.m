function [varphi_up,y,sL,Psi,Phi] = FTS_Obs(E,W,Um,g_hat,xi_hat,varphi,xi_m,bar_am,bar_p)


global h kp kv kw kappa p mu alpha_1 alpha_2

L = E*W*Um';

s = invVee(L*g_hat(1:3,1:3)'-g_hat(1:3,1:3)*L');
sL = s';

y = bar_p - g_hat(1:3,1:3)*bar_am - g_hat(1:3,4);


if norm(sL) == 0
    zL = [0 0 0]';
else
    zL = sL/(((sL)'*(sL))^(1-1/p));
end

Psi = varphi(1:3) + alpha_1*zL;
wL1 = invVee(L*g_hat(1:3,1:3)'*skew(varphi(1:3)) + skew(varphi(1:3))*g_hat(1:3,1:3)*L');
wL=wL1'; 
   


Hw = eye(3,3)-((2*(1-(1/p)))/(sL'*sL))*(sL*sL'); 

w_A2 = kw*Psi/((Psi'*Psi)^(1-1/p));
w_A3 = ( mu*alpha_1/((sL'*sL)^(1-1/p)) )*Hw*wL;
% z1 = sL/((sL'*sL)^(1-1/p));
w_A4 = kp*kappa*alpha_1*(Psi/(Psi'*Psi))*((cross(bar_p, y)'*zL));

omega_dot = (1/mu)*(-kp*sL - w_A2 - w_A3);



if norm(sL) == 0
    z2 = [0 0 0]';
else
    z2 = y/((y'*y)^(1-1/p));
end

Phi = varphi(4:6) + cross(varphi(1:3),bar_p) + alpha_2*z2; 
phi_norm = norm(Phi)
Hy = eye(3,3)-((2*(1-(1/p)))/(y'*y))*(y*y');

vL = varphi(4:6) + cross(varphi(1:3),(bar_p - y));


v_A1 = kp*kappa*y;
v_A2 = kv*Phi/((Phi'*Phi)^(1-1/p));
v_A3 = (alpha_2/((y'*y)^(1-1/p)) )*Hy*vL;
upsilon_dot = cross(bar_p,omega_dot)- v_A1 - v_A2 - v_A3; 

omega_up = h*omega_dot;
upsilon_up = h*upsilon_dot;

varphi_up = [omega_up; upsilon_up];

end