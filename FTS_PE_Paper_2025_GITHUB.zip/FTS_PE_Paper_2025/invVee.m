function y = invVee(R)

% if(R(1,1)==0 & R(2,2)==0 & R(3,3)==0)

y = [-R(2,3), R(1,3), -R(1,2)];
