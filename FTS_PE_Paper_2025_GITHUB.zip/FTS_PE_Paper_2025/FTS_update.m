function [ghat_next, varphi_next, W, Um, y,sL,Psi,Phi,int_val] = FTS_update(xi_m, g_hat, varphi, Um, bar_am, bar_p, xi_hat)

global h K e1 e2 e3

E = [e1 e2 e3];
Um = [Um(:,1) Um(:,2) cross(Um(:,1),Um(:,2))];
W = E'*(E*E')^(-1)*K*(E*E')^(-1)*E;
 
xi_hat = xi_m - AdSE3(invSE3(g_hat))*varphi;


ghat_next = g_hat*expmse3(h*R6tose3(xi_hat));

% [E, W, Um] = measureVect(R);
[varphi_up,y,sL,Psi,Phi] = FTS_Obs(E,W,Um,g_hat,xi_hat,varphi,xi_m,bar_am,bar_p);

varphi_next = varphi + varphi_up;

int_val = xi_hat;

end