function [E, W, Um] = measureVect(R)


global K

e1 = [1  0  0]';
e2 = [0  1  0]';
e3 = [0  0  1]';


E = [e1 e2 e3];


u1 = (R')*e1;
u2 = (R')*e2;

Um = [u1 u2 cross(u1,u2)];

W = E'*(E*E')^(-1)*K*(E*E')^(-1)*E;

end

