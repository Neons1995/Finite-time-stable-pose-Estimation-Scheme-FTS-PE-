function Q = ProjSO3(Qr9)
% ProjSO3 (Created 4/6/2013, AKS)
% projects a 3x3 matrix to SO(3)

Q1=Qr9(1,:);
Q1=Q1/norm(Q1);
Q2=Qr9(2,:);
Q2=Q2-(Q2*Q1')*Q1;
Q2=Q2/norm(Q2);
Q3=cross(Q1,Q2);
Q=[Q1; Q2; Q3];

end

