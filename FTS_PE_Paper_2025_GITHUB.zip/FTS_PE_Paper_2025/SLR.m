function SLR=SLR(L,Rhat)
SLR=unskew(L*Rhat'-Rhat*L');