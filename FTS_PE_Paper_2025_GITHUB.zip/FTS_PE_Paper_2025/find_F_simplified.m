% This function solves the equation F*Jd-Jd*F'=skew(m) 
% using the Newton-Raphson based method from the 
% Melvin et. al article
% Update: 02/23/2015, AKS
% 
% Input:
% Jd
% m
%
% Output:
% F - the solution
% T - the time used for the computation
% err - the error in solving the equation
%
% function [F,T,err]=find_F_NewtonRaphson(Jd,m)
function F=find_F_simplified(Jd,m)


J=trace(Jd)*eye(3)-Jd;

tic
fi=m; % initial guess

nf=norm(fi);
G=sinc(nf/pi)*J*fi+cosc(nf)*cross(fi,J*fi);
%i=1;
while norm(G-m) > 1e-10
   nf=norm(fi);
    G=sin(nf)/nf*J*fi+cosc(nf)*cross(fi,J*fi);
    nabG=(cos(nf)*nf-sin(nf))/nf^3*(J*fi)*fi'+sinc(nf/pi)*J...
        +(sin(nf)*nf-2*(1-cos(nf)))/nf^4*cross(fi,J*fi)*fi'...
        +cosc(nf)*(skew(-J*fi)+[cross(fi,J(:,1)),cross(fi,J(:,2)),cross(fi,J(:,3))]);
    fi=fi+nabG\(m-G);
%    i=i+1;
end
F=expmso3(fi);




function y=cosc(nx)
if nx>0.01 
    y=(1-cos(nx))/nx^2;
else
    y=1/2-nx^2/24+nx^4/720-nx^6/40320;
end

function v=sinc(w)
if w>0.2
    v=sin(w)/w;
    
else
    v=1-w^2/6+w^4/120-w^6/5040+w^8/362880-w^10/39916800;
   
end
