function Eta = R6tose3(eta)
% R6tose3: Transforms a vector eta in R^6 to the square 4x4 
%          matrix representation of se3

if size(eta,1)==1, 
    eta=eta';
end;
Eta=[skew(eta(1:3)) eta(4:6); zeros(1,4)];
