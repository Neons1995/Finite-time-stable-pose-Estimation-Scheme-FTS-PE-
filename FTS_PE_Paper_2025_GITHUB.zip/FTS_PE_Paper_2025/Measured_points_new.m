function [bar_am, bar_p] = Measured_points_new(p_bar_t1,R_t1_f_T,b_t)

bar_p=p_bar_t1';
for i=1:length(R_t1_f_T)
 bar_am(:,i) = R_t1_f_T(:,:,i)'*(p_bar_t1' - b_t(:,i));
end
end