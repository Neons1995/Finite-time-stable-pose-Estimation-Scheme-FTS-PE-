function Gi=invSE3(G)
% Computes inverse of a 4x4 matrix representation of an element of SE(3)

GR=G(1:3,1:3);
Gb=G(1:3,4);
Gi=[GR' -GR'*Gb;zeros(1,3) 1];


