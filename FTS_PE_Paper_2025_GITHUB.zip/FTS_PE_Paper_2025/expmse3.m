function G=expmse3(Xi)

O = [Xi(3,2) Xi(1,3) Xi(2,1)];
Os = skew(O);
Phi=norm(O);

S=eye(3,3) + cosc(Phi)*Os + sind(Phi)*Os^2;

G = [expmso3(O) S*Xi(1:3,4); zeros(1,3) 1];

function y=cosc(x)
if x>0.3 
    y=(1-cos(x))/x^2;
else
    y=1/2-x^2/24+x^4/720-x^6/40320+x^8/3628800-x^10/479001600;
end

function v=sind(u)
if u>0.2
    v=(u-sin(u))/u^3;
else
    v=1/6-u^2/factorial(5)+u^4/factorial(7)-u^6/factorial(9)+u^8/factorial(11);
end